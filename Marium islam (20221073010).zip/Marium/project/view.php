<?php include("conn.php"); ?>

<!DOCTYPE html>
<html lang="en">
<head>
    <title>View Submitted Data</title>
    
</head>
<body>
    <h1>Submitted Student Data</h1>
    <table>
        <tr>
            <th>Field</th>
            <th>Value</th>
        </tr>
        <?php
        if (isset($_POST['register'])) {
            $fname = $_POST['fullname'];
            $sid = $_POST['id'];
            $mail = $_POST['email'];
            $pwd = $_POST['password'];
            $dob = $_POST['dob'];
            $gen = $_POST['gender'];
            $rel = implode(', ', $_POST['religion'] ?? []);
            $dept = $_POST['department'];

            echo "
                <tr><td>Full Name</td><td>$fname</td></tr>
                <tr><td>Student ID</td><td>$sid</td></tr>
                <tr><td>Email</td><td>$mail</td></tr>
                <tr><td>Password</td><td>$pwd</td></tr>
                <tr><td>Date of Birth</td><td>$dob</td></tr>
                <tr><td>Gender</td><td>$gen</td></tr>
                <tr><td>Religion</td><td>$rel</td></tr>
                <tr><td>Department</td><td>$dept</td></tr>
            ";
        } else {
            echo "<tr><td colspan='2'>No data submitted.</td></tr>";
        }
        ?>
    </table>
    <div class="navigation">
        <a href="cg.html"></br>NEXT</a>
    </div>
</body>
</html>
