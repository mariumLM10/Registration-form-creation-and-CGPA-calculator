<?php include("connection.php"); ?>
<!DOCTYPE html>
<html>
    <head>
        <title>Submitted Data</title>
    </head>
    <body>
        <h1>Submitted Data</h1>

        <?php
        if ($_POST['register']) {
            $fname = $_POST['fullname'];
            $id = $_POST['id'];
            $mail = $_POST['email'];
            $pass = $_POST['password'];
            $dob = $_POST['dob'];
            $gen = $_POST['gender'];
            $rel = $_POST['religion'];
            $dept = $_POST['department'];

            echo "
                <div><strong>Full Name:</strong> $fname</div>
                <div><strong>Student ID:</strong> $id</div>
                <div><strong>Email:</strong> $mail</div>
                <div><strong>Password:</strong> $pass</div>
                <div><strong>Date of Birth:</strong> $dob</div>
                <div><strong>Gender:</strong> $gen</div>
                <div><strong>Religion:</strong> $rel</div>
                <div><strong>Department:</strong> $dept</div>
            ";
        } else {
            echo "<p>No data submitted</p>";
        }
        ?>
    </body>
</html>
